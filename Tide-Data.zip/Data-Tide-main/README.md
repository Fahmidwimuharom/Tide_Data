# Data-Tide

1. Fahmi Dwi Muharom       - 5220600014
2. Josua Jonathan Manurung - 5220600026
